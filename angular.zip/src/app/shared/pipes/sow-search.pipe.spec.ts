import { SowSearchPipe } from './sow-search.pipe';

describe('SowSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new SowSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
