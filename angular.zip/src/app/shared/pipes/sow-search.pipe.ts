import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sowSearch'
})
export class SowSearchPipe implements PipeTransform {

  transform(sowReportData: any[], sownums: string): any[] {
    let filteredResults = [];

    if(sowReportData && sownums) {
       filteredResults = sowReportData.filter(res => {
         return res.sowId && res.sowId.toString().match(sownums);
     });
      return filteredResults;
    } else {
            return sowReportData;
    }
  }

}
