import { Component, OnInit, ViewChild,TemplateRef,ViewEncapsulation } from '@angular/core';
import { SowReportService } from './sow-report-service';
import * as _ from 'underscore';
import {NgbModal, NgbModalRef, NgbDatepicker} from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder,FormArray,Validators } from '@angular/forms';
import {ISowReportModel } from './sow-report-model';

@Component({
  selector: 'app-sow-report',
  templateUrl: './sow-report.component.html',
  styleUrls: ['./sow-report.component.scss'],
  providers: [SowReportService],
  encapsulation: ViewEncapsulation.None
})

export class SowReportComponent implements OnInit {

  tabList = [
    {tabName:'Active'},
    {tabName:'Progress'},
    {tabName:'Completed'},
    {tabName:'Cancelled'}
  ];

  businessUnits = [
    {unit:'HCNA'},
    {unit:'TZ Services'},
    {unit:'HCNA TZ Services'}
  ];

   businessAreas = [
    {area:'Consumer and Product'},
    {area:'Healthcare Systems Integration'},
    {area:'Operational Excellence'},
    {area:'ISGR'},
    {area:'Corporate and Finance'},
    {area:'Quality Assurance '},
    {area:'Analytics and Data'}
  ];

  contractTypes = [
    {type:'Fixed Price'},
    {type:'Time & Money'}
  ];

 workTypes = [
    {type:'App Dev'},
    {type:'App Dev and QA'},
    {type:'Security Services'},
    {type:'QA'},
  ];

  sowStatus = [
    {status:'Active'},
    {status:'Progress'},
    {status:'Completed'},
    {status:'Cancelled'}
  ];
  
  sowReportData: ISowReportModel[];
  reportDataBackup = [];
  closeResult: string;
  modalRef: NgbModalRef;
  sowkey: number;
  sowAddForm:FormGroup;
  sowEditForm:FormGroup;
  typeofRecord = 'Active';
  errMessage:string;
  test:string;

  @ViewChild('deleteSow') deleteModal:TemplateRef <any>;
  @ViewChild('addSow') addModal:TemplateRef <any>;
  @ViewChild('editSow') editModal:TemplateRef <any>;

  constructor(private sowReportService: SowReportService, private modalService: NgbModal,private fb: FormBuilder) { }

  ngOnInit() {
   this.getSowData();
  }
  
  getSowData() {
     this.sowReportService.getSowData().subscribe(data => {
          this.reportDataBackup = data;
          this.sowReportData = _.filter(this.reportDataBackup, status => {
               return status.recordType === this.typeofRecord;
           });
      },error => this.errMessage = error);
  }

  loadData(tabName) {
    this.sowReportData = _.filter(this.reportDataBackup, status => {
         this.typeofRecord = tabName ; 
         return status.recordType ===  this.typeofRecord;
    });
  }

//add code start here:
  addRecordPopup(){
    this.modalRef = this.modalService.open(this.addModal,{size:'lg'});
         this.sowAddForm = this.fb.group({
           sowId:['',Validators.required],
           sowDescription:['',Validators.required],
           businessUnit:['',Validators.required],
           masterServiceAgreement:['Cognizant'],
           workType:['',Validators.required],
           sowAmount:['',Validators.required],
           recordType:['',Validators.required],
           status:['',],
           contractNumber:['',Validators.required],
           amendment:['',Validators.required],
           startDate:['',Validators.required],
           endDate:['',Validators.required],
           contractType:['',Validators.required],
           excellusContact:['',Validators.required],
           businessArea:['',Validators.required]
    });
  }  

    
  editRecordPopup(sowEditData:ISowReportModel) {
    this.modalRef = this.modalService.open(this.editModal,{size:'lg'});
         this.sowEditForm = this.fb.group({
           sowId:[sowEditData.sowId,Validators.required],
           sowDescription:[sowEditData.sowDescription,Validators.required],
           businessUnit:[sowEditData.businessUnit,Validators.required],
           masterServiceAgreement:[sowEditData.masterServiceAgreement],
           workType:[sowEditData.workType,Validators.required],
           sowAmount:[sowEditData.sowAmount,Validators.required],
           recordType:[sowEditData.recordType,Validators.required],
           status:[sowEditData.status],
           contractNumber:[sowEditData.contractNumber,Validators.required],
           amendment:[sowEditData.amendment,Validators.required],
           startDate:[sowEditData.startDate,Validators.required],
           endDate:[sowEditData.endDate,Validators.required],
           contractType:[sowEditData.contractType,Validators.required],
           excellusContact:[sowEditData.excellusContact,Validators.required],
           businessArea:[sowEditData.businessArea,Validators.required]

        })

  }

  onSubmit() {
    this.sowReportService.addSowData(this.sowAddForm)
     .subscribe(response => {
              this.modalRef.close(); 
              alert("Sow Added successfully");
              this.getSowData();
     },(error) => {
        this.errMessage = error;
       }
     );
     
  }

    onUpdate() {
    this.sowReportService.updateSowData(this.sowEditForm)
     .subscribe(response => {
              this.modalRef.close(); 
              alert("Sow updated successfully");
              this.getSowData();
     },(error) => {
        this.errMessage = error;
       }
     );
     
  }


//delete code start here:
  deleteRecordPopup(sownum){
    this.modalRef = this.modalService.open(this.deleteModal);
    this.sowkey = sownum;
  }  

  deleteSowMethod() {
     this.sowReportService.deleteSowData(this.sowkey)
         .subscribe(response => {
                       this.reportDataBackup = _.filter(this.reportDataBackup, remove => {
                            return remove.sowId !== this.sowkey;
                       });
                       alert("Sow " + this.sowkey + " deleted successfully");   
                       this.sowReportData = _.filter(this.reportDataBackup, status => {                            return status.recordType === this.typeofRecord;
                       });                                 
                   },(error) => {
                        this.errMessage = error;
                      }
         );
         
      this.modalRef.close();
  }


}
