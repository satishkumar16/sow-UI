

export interface ISowReportModel {
    businessUnit:string;
    masterServiceAgreement:string;
    contractNumber:string;
    sowId:string;
    amendment:number;
    sowDescription:string;
    contractType:string;
    workType:string;
    businessArea;string;
    excellusContact:string;
    sowAmount:number;
    startDate: string; 
    endDate:string;
    status: string;
    recordType: string;
}

