import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders,HttpErrorResponse} from '@angular/common/http';
import {ISowReportModel } from './sow-report-model';
import {catchError } from 'rxjs/operators' ;
import { Observable,throwError} from 'rxjs';
import format from 'date-fns/format';


@Injectable()
export class SowReportService {
  
  //getSowReportUrl = "getSowReport";
  getSowReportUrl = 'http://localhost:8080/getsow';
  addSowReportUrl = 'http://localhost:8080/addsow';
  updateSowReportUrl = 'http://localhost:8080/updatesow';
  deleteSowReportUrl = 'http://localhost:8080/deletesow';

  constructor(private http:HttpClient){}

 getSowData(): Observable<ISowReportModel[]> {
   return this.http.get<ISowReportModel[]>(this.getSowReportUrl)
                   .pipe(catchError(this.errorhandler));
 }


 addSowData(sowAddData):Observable<any> {
   const payloadData = sowAddData.value;
   payloadData.startDate = this.dateFormatter(payloadData.startDate);
   payloadData.endDate = this.dateFormatter(payloadData.endDate);
   
   return this.http.post<ISowReportModel[]>(this.addSowReportUrl,payloadData)
                   .pipe(catchError(this.errorhandler)); 
}

updateSowData(sowUpdateData): Observable<any> {
    const payloadUpdateData = sowUpdateData.value;
    payloadUpdateData.startDate = this.dateFormatter(payloadUpdateData.startDate);
    payloadUpdateData.endDate = this.dateFormatter(payloadUpdateData.endDate);
   
    return this.http.put<ISowReportModel[]>(`${this.updateSowReportUrl}/${payloadUpdateData.sowId}`,payloadUpdateData)
                    .pipe(catchError(this.errorhandler));
}


deleteSowData(sowid): Observable<any> {
  return this.http.delete(`${this.deleteSowReportUrl}/${sowid}`,{responseType:'text'})
                  .pipe(catchError(this.errorhandler));
}


 errorhandler(errorResponse:HttpErrorResponse) {
     if(errorResponse instanceof HttpErrorResponse) 
        return throwError(errorResponse.message);
 }


  dateFormatter(dateValue): string {
    const dateFormat = new Date(dateValue.year,dateValue.month,dateValue.day).toISOString();
    return dateFormat.substring(0, 10); 
  }

}
